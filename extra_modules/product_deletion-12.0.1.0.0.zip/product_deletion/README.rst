Product Removal Authorisation v11
=================================
User in the group "Product Deletion" can only delete the products. Those who are not in the
group cant delete the product. Odoo will raise a warning if the user in not in the group

Credits
=======
Cybrosys Techno Solutions

Contributors
------------
*  Niyas Raphy, Cybrosys <niyas@cybrosys.in>