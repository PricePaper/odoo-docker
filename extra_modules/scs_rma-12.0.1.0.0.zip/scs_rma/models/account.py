# See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class AccountInvoice(models.Model):
    _inherit = 'account.invoice'

    rma_id = fields.Many2one('rma.ret.mer.auth', string='RMA')
