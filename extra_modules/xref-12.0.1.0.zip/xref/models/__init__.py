# -*- coding: utf-8 -*-

from . import reference
from . import ir_model
from . import mail_thread