# See LICENSE file for full copyright and licensing details.

from . import res_company
from . import stock
from . import rma
from . import account
from . import sale
from . import purchase
