===========================================================
Return Merchandise Authorization Return Exchange Management
===========================================================

RMA allows you to process several return functions, such as exchanges, refunds, store credits and return of return.
RMA can be initiated by the Sale order/Purchase Order or can be initiated by the Picking at any time after an order has been placed.

============
Installation
============

To install this module, you need to:

install Return Merchandise Authorization


=====
Usage
=====

To use this module, you need to:

go to apps, then install module to apply this functionality.

===========
Bug Tracker
===========

If you spotted it, help us smashing it by providing a detailed and welcomed feedback here.
contact us for support or help with technical issues. <mailto:support@serpentcs.com>

======
Author
======

Serpent Consulting Services PVT. LTD. <http://serpentcs.com>

==========
Maintainer
==========

Serpent Consulting Services PVT. LTD.

This module is maintained by the SerpentCS.

To contribute to this module, please visit http://serpentcs.com.

============
Similar Apps
============

Return Merchandise Authorization Return Exchange Management
rma return material replace exchange product
Odoo Return Merchandise Authorization
Return Merchandise Authorization odoo
Return Merchandise Authorization in odoo
rma return merchandise authorization
Return Material Authorization Software
Return Merchandise Authorization
return merchandise authorization
RMA Configurations
RMA Stock Picking
RMA Credit Note
RMA management software
RMA Invoices
RMA Portal
RMA Return goods
Exchange goods
Credit notes
Replace item
Goods Return Refund
Exchange
Payback
Return
refund
Merchandise
Authorization
Management
Exchange
Odoo RMA
RMA Odoo
RMA
